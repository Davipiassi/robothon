#!/bin/bash

zip -r "CardsOperations.zip" * -x "CardsOperations.zip"